# NAMUNA: yangi ishda ko'chirib, G ro'yxatini shu faylga mos to'ldiring.
import re,sys
sys.path.insert(0,'/projects/sandbox/work')
HG=str.maketrans("аеорсухіАВЕКМНОРСТХ","aeopcuxiABEKMHOPCTX")
HG=str.maketrans({'а':'a','е':'e','о':'o','р':'p','с':'c','у':'y','х':'x','і':'i','А':'A','В':'B','Е':'E','К':'K','М':'M','Н':'H','О':'O','Р':'P','С':'C','Т':'T','Х':'X','к':'k'})
CELL={}   # (qator, 'A'..'E'): "yangi matn"   (A=savol, B..E=variant A..D)
G=[
("Xasharot","Hasharot"),("xashorat","hasharot"),("Xashorat","Hasharot"),("xujayra","hujayra"),("xozirgi","hozirgi"),("Xozirgi","Hozirgi"),
("xavzalari","havzalari"),("xavzasi","havzasi"),("xo'jaynini","xo'jayinini"),("xidretseptor","hidretseptor"),("ximoya","himoya"),("xisob","hisob"),
("muqit","muhit"),("qayvon","hayvon"),("Qo’zqatuvchi","Qo’zg‘atuvchi"),("iskaptopar","iskabtopar"),("guruqini","guruhini"),("aloqidalab","alohidalab"),
("guruq","guruh"),("kupay","ko‘pay"),("kuprok","ko‘proq"),("gametotsit","gametosit"),("kassalliklarni","kasalliklarni"),("Entеriobioz","Enterobioz"),
("`","‘"),("hisolanadi","hisoblanadi"),("quydagi","quyidagi"),("tog'ri","to'g'ri"),("tranmissiv","transmissiv"),
("xasharot","hasharot"),("xamshira","hamshira"),("Epidemologik","Epidemiologik"),("xayvon","hayvon"),("Axoli","Aholi"),("axoli","aholi"),
("xudud","hudud"),("Xudud","Hudud"),("xarorat","harorat"),("xavo","havo"),("Xavo","Havo"),("maxsulot","mahsulot"),("xafta","hafta"),
("xisoblan","hisoblan"),("xayot","hayot"),("xamma","hamma"),("Xamma","Hamma"),("xajm","hajm"),("xarakat","harakat"),("taxlil","tahlil"),
("ist'emol","iste'mol"),("chakiradi","chaqiradi"),("gel'mint","gelmint"),("Gel'mint","Gelmint"),("fiksasiya","fiksatsiya"),
("1 – 1,5 pa","1 – 1,5 atm"),("1-1,5 pa","1-1,5 atm"),("10 pa","10 atm"),("eliminasiya","eliminatsiya"),("klassifikasiya","klassifikatsiya"),("lokalizasiya","lokalizatsiya"),("kombinasiya","kombinatsiya"),
("populyasiya","populyatsiya"),("transplantasiya","transplantatsiya"),("degelmintizasiya","degelmintizatsiya"),
]
def fix(row,col,text):
    if (row,col) in CELL: return CELL[(row,col)]
    t=text.translate(HG)
    for a,b in G: t=t.replace(a,b)
    t=re.sub(r',(?=[A-Za-z‘’\'])',', ',t)
    t=re.sub(r'\s{2,}',' ',t).strip()
    return t
