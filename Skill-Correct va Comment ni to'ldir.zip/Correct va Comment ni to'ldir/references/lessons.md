# Oldingi seanslardan olingan saboqlar

- **Manba fayl turlari ikki xil.** (1) `inlineStr` va F/G kataklari bo'sh `t="n"` (openpyxl bilan yozilgan), (2) `sharedStrings.xml` va F/G kataklari umuman yo'q (Excel). Skript ikkalasini ham qo'llaydi. Qatorlarda `spans="1:5"` bo'lsa, `1:7` ga yangilanadi.
- **ZIP yozishda** `zo.writestr(asl_ZipInfo, data)` ishlatmang: "Bad CRC-32" xatosi chiqishi mumkin. Yangi `ZipInfo(filename, date_time)` yarating.
- **Sandbox `/tmp` saqlanmaydi**, ish fayllarini `/projects/sandbox/work*/` ichida saqlang. Sandbox'da `openpyxl` yo'q, shuning uchun XML bilan ishlang.
- **Kutubxona hujjatlari kirillcha**, qidiruv so'zini kirillda yozing. Hujjat matnini `.txt` ga saqlab `grep` qiling.
- **Ustun xaritasi**: variant "A" matni B ustunda. `CELL` va `fix()` da ustun harfi (A..E) ishlatiladi, variant harfi (A..D) emas. Bu ikkisini aralashtirish eng ko'p uchragan xato.
- **Tuzatilgan matn Comment ga ko'chiriladi.** Kirillcha yoki xato javob matni Comment ga o'tib ketmasligi uchun avval `fix()`, keyin `comment()`.
- **F ustunida ro'yxatli tekshiruv (A–D)** bor. "B, D" kabi qiymatda Excel tahrirlashda ogohlantirishi mumkin, fayl ochilishiga to'sqinlik qilmaydi. Foydalanuvchi so'ramasa validatsiyani o'zgartirmang.
- **Test bazasi turlari**: ba'zi bazalarda (masalan hasharotlar morfologiyasi) variantlarda to'g'ri javob bo'lmaydi, bir xil variantlar bo'ladi, savollar kesilgan. Bunday savollar **shubhali** deb belgilanadi, foydalanuvchi tekshirishi kerak.
- **Mahalliy aniq raqamlar** (muddat, masofa, hudud, hujjat raqami) uchun manba topilmasa, taxminni yozing-u, shubhali + "aniq manba topilmadi" deb belgilang.
- **Yuklash**: `main` da bo'lsangiz, avval yangi branch oching, so'ng commit va push. Fayllarni aniq nom bilan `git add` qiling.
- **Foydalanuvchi ish davomida yo'riqnoma bersa** (masalan "imlo va kirillni ham tuzat"), shu daqiqadan boshlab qo'llang va avval bajarilgan bo'laklarni qayta yig'ing (skript hammasini qayta quradi).
