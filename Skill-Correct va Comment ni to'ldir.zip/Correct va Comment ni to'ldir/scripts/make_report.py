#!/usr/bin/env python3
"""Hisobot .md yozadi. Ishlatish: python make_report.py --work ish_papka --out hisobot.md --title "fayl nomi" [--fixes fixes.py]"""
import json, re, argparse, os, importlib.util
ap = argparse.ArgumentParser()
ap.add_argument('--work', required=True); ap.add_argument('--out', required=True)
ap.add_argument('--title', default='test'); ap.add_argument('--fixes')
a = ap.parse_args()
fx = None
if a.fixes:
    sp = importlib.util.spec_from_file_location('fx', a.fixes); fx = importlib.util.module_from_spec(sp); sp.loader.exec_module(fx)
fixt = (lambda r, c, t: fx.fix(r, c, t)) if fx else (lambda r, c, t: t)
Q = {d['row']: d for d in json.load(open(os.path.join(a.work, 'q.json')))}
A = json.load(open(os.path.join(a.work, 'A.json'))); FL = json.load(open(os.path.join(a.work, 'fixlog.json')))
cyr = re.compile('[А-Яа-яЁёЎўҚқҒғҲҳ]')
nm = {'A': 'Question', 'B': 'A', 'C': 'B', 'D': 'C', 'E': 'D'}
qt = lambda r: fixt(int(r), 'A', Q[int(r)]['A']).replace('|', '/')
L = [f"# {a.title}: hisobot\n\n", f"Tekshirilgan savollar: {len(A)}.\n\n"]
L += ["## 1. Kaliti tuzatilgan savollar\n\n", "(qator | eski | yangi | savol | sabab). Asl Correct bo'sh bo'lsa: yo'q.\n\n"]
mj = [r for r, v in A.items() if ',' in v[0]]
L += [f"## 2. Ko'p javobli savollar ({len(mj)} ta)\n\n", "| qator | javoblar | savol |\n|---|---|---|\n"] + [f"| {r} | {A[r][0]} | {qt(r)} |\n" for r in mj]
sh = [r for r, v in A.items() if v[3] == 'shubhali']
L += [f"\n## 3. Shubhali savollar ({len(sh)} ta)\n\n", "| qator | kalit | savol | sabab |\n|---|---|---|---|\n"]
L += [f"| {r} | {A[r][0]} | {qt(r)} | {(A[r][4] or A[r][1]).replace('|', '/')} |\n" for r in sh]
cy = [x for x in FL if cyr.search(x[2])]
L += [f"\n## 4. Kirill harflari ({len(cy)} katak)\n\n", "| qator | katak | eski | yangi |\n|---|---|---|---|\n"]
L += [f"| {r} | {nm[k]} | {o.replace('|', '/')} | {n.replace('|', '/')} |\n" for r, k, o, n in cy]
L += [f"\n## 5. Imlo tuzatishlari ({len(FL) - len(cy)} katak)\n\n", "| qator | katak | eski | yangi |\n|---|---|---|---|\n"]
L += [f"| {r} | {nm[k]} | {o.replace('|', '/')} | {n.replace('|', '/')} |\n" for r, k, o, n in FL if not cyr.search(o)]
open(a.out, 'w', encoding='utf8').write(''.join(L)); print(len(mj), len(sh), len(cy), len(FL))
