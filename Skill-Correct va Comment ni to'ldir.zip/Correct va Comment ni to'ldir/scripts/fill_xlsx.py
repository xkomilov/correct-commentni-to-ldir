#!/usr/bin/env python3
"""Test .xlsx (Question|A|B|C|D|Correct|Comment) ga Correct va Comment yozadi.
Faqat sheet1.xml o'zgaradi (XML darajasida). Boshqa ZIP qismlari baytma-bayt saqlanadi.

Ishlatish:
  python fill_xlsx.py --src asl.xlsx --out natija/asl_izohli.xlsx --work ish_papka \
      --answers "ish_papka/ans_*.py" --sources ish_papka/sources.py [--fixes ish_papka/fixes.py]

answers fayllari: A = {qator: (harflar, asos, [manba_kalitlari], holat, eslatma)}
  harflar: "B" yoki "A, C" (alifbo tartibida), holat: None | 'shubhali'
sources.py: S = {kalit: "to'liq manba nomi"}
fixes.py (ixtiyoriy): fix(row, col, text) -> tuzatilgan matn (col: A=Question, B..E = variant A..D)
"""
import re, html, json, zipfile, glob, sys, os, argparse, importlib.util
from xml.sax.saxutils import escape

ap = argparse.ArgumentParser()
ap.add_argument('--src', required=True); ap.add_argument('--out', required=True)
ap.add_argument('--work', required=True); ap.add_argument('--answers', required=True)
ap.add_argument('--sources', required=True); ap.add_argument('--fixes')
ap.add_argument('--sheet', default='xl/worksheets/sheet1.xml')
a = ap.parse_args()

def load(path, name):
    sp = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(sp); sp.loader.exec_module(m); return m
S = load(a.sources, 'srcs').S
fx = load(a.fixes, 'fx') if a.fixes else None
fix = (lambda r, c, t: fx.fix(r, c, t)) if fx else (lambda r, c, t: t)

A = {}
for f in sorted(glob.glob(a.answers)):
    ns = {}; exec(open(f, encoding='utf8').read(), ns); A.update(ns['A'])

z = zipfile.ZipFile(a.src)
xml = z.read(a.sheet).decode('utf8')
SS = []
if 'xl/sharedStrings.xml' in z.namelist():
    ss = z.read('xl/sharedStrings.xml').decode('utf8')
    SS = [html.unescape(''.join(re.findall(r'<t[^>]*>(.*?)</t>', x, re.S))) for x in re.findall(r'<si>(.*?)</si>', ss, re.S)]

def cells(body):
    d = {}
    for m in re.finditer(r'<c r="([A-Z]+)\d+"([^>]*?)(?:/>|>(.*?)</c>)', body, re.S):
        col, attr, inner = m.groups(); v = ''
        if inner:
            vv = re.search(r'<v>(.*?)</v>', inner)
            if 't="s"' in attr and vv: v = SS[int(vv.group(1))]
            else: v = html.unescape(''.join(re.findall(r'<t[^>]*>(.*?)</t>', inner, re.S)))
        d[col] = v
    return d

COL = {'A': 'B', 'B': 'C', 'C': 'D', 'D': 'E'}
FIXLOG = []
def apply_fix(row, d):
    out = dict(d)
    for k in 'ABCDE':
        if d.get(k):
            n = fix(row, k, d[k])
            if n != d[k]: FIXLOG.append((row, k, d[k], n))
            out[k] = n
    return out

def comment(row, d):
    letters, asos, src, _, _ = A[row]
    ls = [x.strip() for x in letters.split(',')]
    ans = '; '.join(d[COL[x]].strip() for x in ls)
    sep = '' if ans.endswith(('.', '!', '?')) else '.'
    man = '; '.join(S[k] for k in src) if src else 'aniq manba topilmadi'
    return f"To'g'ri javob: {ans}{sep} Asos: {asos} Manba: {man}."

def mk(ref, row, val, s): return f'<c r="{ref}{row}" s="{s}" t="inlineStr"><is><t>{escape(val)}</t></is></c>'

def rep(m):
    row = int(m.group(1)); attrs = m.group(2); body = m.group(3)
    if row not in A: return m.group(0)
    d0 = cells(body); d = apply_fix(row, d0)
    for k in 'ABCDE':            # matni o'zgargan kataklarni inlineStr qilib yozish
        if d.get(k, '') != d0.get(k, ''):
            body = re.sub(r'<c r="%s%d"([^>]*?)>(?:<v>\d+</v>|<is>.*?</is>)</c>' % (k, row),
                          lambda mm: mk(k, row, d[k], (re.search(r's="(\d+)"', mm.group(0)) or [0, '1'])[1] if re.search(r's="(\d+)"', mm.group(0)) else '1'),
                          body, count=1, flags=re.S)
    sm = re.search(r'<c r="E%d"[^>]*? s="(\d+)"' % row, body); s = sm.group(1) if sm else '1'
    body = re.sub(r'<c r="[FG]%d"[^>]*?(?:/>|>.*?</c>)' % row, '', body, flags=re.S)
    body += mk('F', row, ', '.join(x.strip() for x in A[row][0].split(',')), s) + mk('G', row, comment(row, d), s)
    attrs = re.sub(r'spans="1:\d+"', 'spans="1:7"', attrs)
    return f'<row r="{row}"{attrs}>{body}</row>'

new = re.sub(r'<row r="(\d+)"([^>]*)>(.*?)</row>', rep, xml, flags=re.S)
os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True); os.makedirs(a.work, exist_ok=True)
tmp = a.out + '.tmp'
try:
    with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as zo:
        for it in z.infolist():
            data = z.read(it.filename)
            if it.filename == a.sheet: data = new.encode('utf8')
            zi = zipfile.ZipInfo(it.filename, it.date_time); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = it.external_attr
            zo.writestr(zi, data)
    os.replace(tmp, a.out)
except PermissionError:
    alt = os.path.join(a.work, os.path.basename(a.out)); os.replace(tmp, alt)
    print(f'EBUSY: natija fayli band. Vaqtinchalik yozildi: {alt}. Foydalanuvchidan faylni yopishni so\'rang.'); sys.exit(2)

# ---- AVTOMATIK TEKSHIRUV ----
def read(path):
    zz = zipfile.ZipFile(path); x = zz.read(a.sheet).decode('utf8')
    return {int(n): cells(b) for n, b in re.findall(r'<row r="(\d+)"[^>]*>(.*?)</row>', x, re.S)}
o, n = read(a.src), read(a.out)
cyr = re.compile('[А-Яа-яЁёЎўҚқҒғҲҳ]')
bad = []
for r, d in n.items():
    if r == 1 or r not in A: continue
    ex = {k: (fix(r, k, o[r][k]) if o[r].get(k) else '') for k in 'ABCDE'}
    for k in 'ABCDE':
        if ex[k] != (d.get(k) or ''): bad.append((r, 'matn kutilganidan farq', k))
        if cyr.search(d.get(k) or ''): bad.append((r, 'A-E kirill', k))
    g, f = d.get('G', ''), d.get('F', '')
    if not re.fullmatch(r'[A-D](, [A-D])*', f) or f != ', '.join(sorted(set(f.split(', ')))): bad.append((r, 'F', f))
    if not g.startswith("To'g'ri javob: ") or not g.endswith('.') or 'Manba: ' not in g: bad.append((r, 'G format'))
    gg = g
    for x in [y.strip() for y in A[r][0].split(',')]:
        if ex[COL[x]].strip() not in g: bad.append((r, "javob matni yo'q"))
        gg = gg.replace(ex[COL[x]].strip(), '')
    if cyr.search(gg): bad.append((r, 'G kirill'))
z2 = zipfile.ZipFile(a.out)
for nm in z.namelist():
    if nm != a.sheet and z.read(nm) != z2.read(nm): bad.append(('zip', nm))
missing = [r for r in n if r > 1 and r not in A]
print(f'javob berilgan: {len(A)}; javobsiz qatorlar: {len(missing)}; xatolar: {bad}; tuzatilgan kataklar: {len(FIXLOG)}')
json.dump({str(k): v for k, v in A.items()}, open(os.path.join(a.work, 'A.json'), 'w'), ensure_ascii=False)
json.dump(FIXLOG, open(os.path.join(a.work, 'fixlog.json'), 'w'), ensure_ascii=False)
json.dump([{**{k: v for k, v in d.items()}, 'row': r} for r, d in sorted(o.items())], open(os.path.join(a.work, 'q.json'), 'w'), ensure_ascii=False)
sys.exit(1 if bad else 0)
